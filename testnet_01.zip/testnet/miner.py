# https://moneroexamples.github.io/python-json-rpc/

import sys
import requests
import json

# execute an rpc request
def execute_rpc(inputs, port):
    return requests.post(
        "http://localhost:"+port+"/json_rpc", # node is running on port
        data=json.dumps(inputs),
        headers={'content-type': 'application/json'}) # standard json header

def main():
    if(len(sys.argv) < 3):
        print("please pass # of blocks, wallet address and port as arguments")
        exit()
    blocks = int(sys.argv[1])
    address = str(sys.argv[2])
    port = str(sys.argv[3])
    blocktemplate = ""
    
    # procedure/method to call
    rpc_input_getTemplate = {
           "method": "getblocktemplate",
           "params": {
                "wallet_address": address,
                "reserve_size" : 20 # leaves a part of the block template empty
            }
    }

    # add standard rpc values
    rpc_input_getTemplate.update({"jsonrpc": "2.0", "id": "0"})
    
    # get template and submit block for multiple blocks
    for i in range(blocks):
        
        # execute the rpc request  
        response_getTemplate = execute_rpc(rpc_input_getTemplate, port)

        # get json output
        if("error" in response_getTemplate.json()):
            print(" ")
            print("error: ", response_getTemplate.json())
        else:
            blocktemplate = response_getTemplate.json()["result"]["blocktemplate_blob"]

            # update submit block call
            rpc_input_submitblock = {
                   "method": "submitblock",
                   "params": [ blocktemplate ]
            }
            rpc_input_submitblock.update({"jsonrpc": "2.0", "id": "0"})

            # execute the rpc request
            response_submitBlock = execute_rpc(rpc_input_submitblock, port)

            print(response_submitBlock.json())


if __name__ == "__main__":
    main()
